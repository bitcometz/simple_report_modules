/ALNAS01/software/PUBLIC/conda/envs/python2.7.10/bin/python /HWNAS12/RAD/zhangjinbo/01.release/00.reports/bins/report.py asm.html.txt ./
